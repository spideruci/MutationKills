package org.pitest.process;

/**
 * Returns the path to a java binary
 */
public interface JavaExecutableLocator {
  String javaExecutable();
}
