package com.example.systemtest;

import org.pitest.simpletest.TestAnnotationForTesting;

public class NoMutationsTest {
    @TestAnnotationForTesting
    public void pass() {

    }
}
