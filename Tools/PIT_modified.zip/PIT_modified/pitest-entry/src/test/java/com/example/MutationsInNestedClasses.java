package com.example;

public class MutationsInNestedClasses {

  public static class Foo {
    public static boolean fooMethod() {
      return true;
    }
  }

  public static class Bar {
    public static boolean barMethod() {
      return true;
    }
  }
}
