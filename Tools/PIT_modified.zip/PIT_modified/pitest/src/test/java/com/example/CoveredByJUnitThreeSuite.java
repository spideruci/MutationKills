package com.example;

public class CoveredByJUnitThreeSuite {

  public int foo() {
    return 1;
  }
}
