package com.example.blockcoverage;

import org.junit.Test;

public class HasTernaryTest {

  @Test
  public void testTernary(){
    int ret = HasTernaryTestee.mutable(10);

  }
}
