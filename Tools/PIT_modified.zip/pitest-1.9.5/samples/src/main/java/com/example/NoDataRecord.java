package com.example;

public record NoDataRecord() {

}