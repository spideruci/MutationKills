package com.example.mutatablecodeintest;

public class Mutee {

  public static int returnOne() {
    return 1;
  }

}
