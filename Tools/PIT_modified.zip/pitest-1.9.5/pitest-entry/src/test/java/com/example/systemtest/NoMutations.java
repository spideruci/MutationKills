package com.example.systemtest;

public class NoMutations {

}
